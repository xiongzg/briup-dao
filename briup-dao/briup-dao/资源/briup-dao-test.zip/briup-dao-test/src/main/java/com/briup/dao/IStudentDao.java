package com.briup.dao;
import com.briup.bean.Student;
import com.briup.base.jdbc.dao.IBaseDao;

public interface IStudentDao extends IBaseDao<Student,java.lang.Long>{

}