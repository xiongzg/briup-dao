package com.briup.dao;
import com.briup.bean.Book;
import com.briup.base.jdbc.dao.IBaseDao;

public interface IBookDao extends IBaseDao<Book,java.lang.Long>{

}