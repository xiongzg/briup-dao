package com.briup.service;

import com.briup.bean.Book;
import com.briup.base.jdbc.service.IBaseService;

public interface IBookService extends IBaseService<Book,java.lang.Long>{


}