package com.briup.service;

import com.briup.bean.Group;
import com.briup.base.jdbc.service.IBaseService;

public interface IGroupService extends IBaseService<Group,java.lang.Long>{


}