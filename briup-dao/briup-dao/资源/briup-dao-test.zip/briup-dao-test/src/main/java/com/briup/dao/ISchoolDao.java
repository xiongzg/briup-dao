package com.briup.dao;
import com.briup.bean.School;
import com.briup.base.jdbc.dao.IBaseDao;

public interface ISchoolDao extends IBaseDao<School,java.lang.Long>{

}