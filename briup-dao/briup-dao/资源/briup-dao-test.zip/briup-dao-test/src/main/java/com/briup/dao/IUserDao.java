package com.briup.dao;
import com.briup.bean.User;
import com.briup.base.jdbc.dao.IBaseDao;

public interface IUserDao extends IBaseDao<User,java.lang.Long>{

}