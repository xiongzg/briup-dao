package com.briup.service;

import com.briup.bean.School;
import com.briup.base.jdbc.service.IBaseService;

public interface ISchoolService extends IBaseService<School,java.lang.Long>{


}