package com.briup.dao;
import com.briup.bean.Course;
import com.briup.base.jdbc.dao.IBaseDao;

public interface ICourseDao extends IBaseDao<Course,java.lang.Long>{

}