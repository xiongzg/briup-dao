package com.briup.dao;
import com.briup.bean.Group;
import com.briup.base.jdbc.dao.IBaseDao;

public interface IGroupDao extends IBaseDao<Group,java.lang.Long>{

}