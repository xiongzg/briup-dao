package com.briup.service;

import com.briup.bean.Course;
import com.briup.base.jdbc.service.IBaseService;

public interface ICourseService extends IBaseService<Course,java.lang.Long>{


}