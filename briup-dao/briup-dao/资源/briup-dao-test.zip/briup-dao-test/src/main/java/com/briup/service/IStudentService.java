package com.briup.service;

import com.briup.bean.Student;
import com.briup.base.jdbc.service.IBaseService;

public interface IStudentService extends IBaseService<Student,java.lang.Long>{


}