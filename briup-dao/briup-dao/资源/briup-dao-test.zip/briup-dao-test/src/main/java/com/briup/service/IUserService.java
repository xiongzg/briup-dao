package com.briup.service;

import com.briup.bean.User;
import com.briup.base.jdbc.service.IBaseService;

public interface IUserService extends IBaseService<User,java.lang.Long>{


}